#ifndef _ROS_custom_msgs_imu_readings_h
#define _ROS_custom_msgs_imu_readings_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace custom_msgs
{

  class imu_readings : public ros::Msg
  {
    public:
      double gyro[3];
      double accel[3];
      double angularVelocity[3];

    imu_readings():
      gyro(),
      accel(),
      angularVelocity()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      for( uint32_t i = 0; i < 3; i++){
      union {
        double real;
        uint64_t base;
      } u_gyroi;
      u_gyroi.real = this->gyro[i];
      *(outbuffer + offset + 0) = (u_gyroi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gyroi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_gyroi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_gyroi.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_gyroi.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_gyroi.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_gyroi.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_gyroi.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->gyro[i]);
      }
      for( uint32_t i = 0; i < 3; i++){
      union {
        double real;
        uint64_t base;
      } u_acceli;
      u_acceli.real = this->accel[i];
      *(outbuffer + offset + 0) = (u_acceli.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_acceli.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_acceli.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_acceli.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_acceli.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_acceli.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_acceli.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_acceli.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->accel[i]);
      }
      for( uint32_t i = 0; i < 3; i++){
      union {
        double real;
        uint64_t base;
      } u_angularVelocityi;
      u_angularVelocityi.real = this->angularVelocity[i];
      *(outbuffer + offset + 0) = (u_angularVelocityi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_angularVelocityi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_angularVelocityi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_angularVelocityi.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_angularVelocityi.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_angularVelocityi.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_angularVelocityi.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_angularVelocityi.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->angularVelocity[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      for( uint32_t i = 0; i < 3; i++){
      union {
        double real;
        uint64_t base;
      } u_gyroi;
      u_gyroi.base = 0;
      u_gyroi.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gyroi.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_gyroi.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_gyroi.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_gyroi.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_gyroi.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_gyroi.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_gyroi.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->gyro[i] = u_gyroi.real;
      offset += sizeof(this->gyro[i]);
      }
      for( uint32_t i = 0; i < 3; i++){
      union {
        double real;
        uint64_t base;
      } u_acceli;
      u_acceli.base = 0;
      u_acceli.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_acceli.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_acceli.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_acceli.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_acceli.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_acceli.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_acceli.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_acceli.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->accel[i] = u_acceli.real;
      offset += sizeof(this->accel[i]);
      }
      for( uint32_t i = 0; i < 3; i++){
      union {
        double real;
        uint64_t base;
      } u_angularVelocityi;
      u_angularVelocityi.base = 0;
      u_angularVelocityi.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_angularVelocityi.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_angularVelocityi.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_angularVelocityi.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_angularVelocityi.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_angularVelocityi.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_angularVelocityi.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_angularVelocityi.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->angularVelocity[i] = u_angularVelocityi.real;
      offset += sizeof(this->angularVelocity[i]);
      }
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/imu_readings"; };
    virtual const char * getMD5() override { return "bd2139e44d32f5b694c2e2d1e9124009"; };

  };

}
#endif
