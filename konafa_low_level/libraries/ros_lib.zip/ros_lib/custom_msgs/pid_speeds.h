#ifndef _ROS_custom_msgs_pid_speeds_h
#define _ROS_custom_msgs_pid_speeds_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace custom_msgs
{

  class pid_speeds : public ros::Msg
  {
    public:
      int32_t setpoint[4];

    pid_speeds():
      setpoint()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      for( uint32_t i = 0; i < 4; i++){
      union {
        int32_t real;
        uint32_t base;
      } u_setpointi;
      u_setpointi.real = this->setpoint[i];
      *(outbuffer + offset + 0) = (u_setpointi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_setpointi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_setpointi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_setpointi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->setpoint[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      for( uint32_t i = 0; i < 4; i++){
      union {
        int32_t real;
        uint32_t base;
      } u_setpointi;
      u_setpointi.base = 0;
      u_setpointi.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_setpointi.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_setpointi.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_setpointi.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->setpoint[i] = u_setpointi.real;
      offset += sizeof(this->setpoint[i]);
      }
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/pid_speeds"; };
    virtual const char * getMD5() override { return "bb95e5b1f20905f4ab1c05dceeb5f18e"; };

  };

}
#endif
