	/*  =============================================
PIDF library for Arduino and STM32 boards.
Author: Robocon21 Team.
First release: June 2nd, 2021

Changelog:
- 2/6/2021  Launched.

This library contains an implementation for the PIDF controller (Proportional
Integral Derivative with Filter) used by MATLAB and Simulink. To make the best
use of this library, model your system on Simulink and design and tune a
discrete-time PIDF controller, then initialize the PIDF object with the tuning
parameters you obtained.
=============================================  */

#if ARDUINO >= 100
  #include <Arduino.h>
#else
  #include <WProgram.h>
#endif

#ifndef MIA_PIDF_h
  #define MIA_PIDF_h

namespace MIA
{
  class PIDF
  {
   public:
    // Constructors
    PIDF(double P, double I, double D, double Ts);

    // Main methods
    double setpoint(void);
    void setpoint(double setpoint);
    double calculate(double processVariable);
    void limitOutput(double outputMin, double outputMax);

    // Modifiers
    void tune(double P, double I, double D);
    double samplingTime(void);
    void samplingTime(double Ts);

    // Debugging helpers
    double _proportional(double error);
    double _integral(double error);
    double _derivative(double error);
    double integralAccumulator {0};

   private:
    double Kp {1.0}, Ki {1.0}, Kd {1.0};
    double Ts {0.2};

    double sp {0.0}, output {0.0};
    double outMin {-65536.0}, outMax {65535.0};

    double lastError {0};

    double initialState {0};
  };
}  // namespace MIA
#endif
